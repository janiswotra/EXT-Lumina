const a="https://lumina-api-kw353kceea-uc.a.run.app/api/v1",p="https://app.yena.ai";export{p as A,a};
