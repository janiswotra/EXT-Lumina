const a="https://app.yena.ai/api/v1",p="https://app.yena.ai";export{p as A,a};
